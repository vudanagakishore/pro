package registration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebean.ConferenceRegisstrationPageFactory;


public class ConferenceRegistrationStepDefinition 
{
	private WebDriver driver;
	
	private ConferenceRegisstrationPageFactory conferencePageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\savuda\\Downloads\\BDD_Files\\chromedriver/chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'ConferenceRegistration' page$")
	public void user_is_on_ConferenceRegistration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:\\Users\\savuda\\workspacebdd\\ConferenceRegistration\\ConferenceRegistartion.html");
		conferencePageFactory= new ConferenceRegisstrationPageFactory(driver);
	  
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("");
		conferencePageFactory.setNextButton();;

	}

	@Then("^displays 'Please fill the First Name'$")
	public void displays_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("vinay");
		conferencePageFactory.setLastName("");
		conferencePageFactory.setNextButton();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("vinay");
		conferencePageFactory.setLastName("venkat");
		conferencePageFactory.setEmail("");
		conferencePageFactory.setNextButton();
	
	    
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid contact number$")
	public void user_enters_invalid_contact_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("vinay");
		conferencePageFactory.setLastName("venkat");
		conferencePageFactory.setEmail("venkat@gmail.com");
		conferencePageFactory.setContactNo("");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please fill the Contact No\\.'$")
	public void display_Please_fill_the_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters wrong contact number$")
	public void user_enters_wrong_contact_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("3454");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please enter valid Contact no'$")
	public void display_Please_enter_valid_Contact_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid Number of People Attending$")
	public void user_enters_invalid_Number_of_People_Attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		
		conferencePageFactory.setNextButton();
	
	    
	}

	@Then("^display 'Number of people attending'$")
	public void display_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter Building name and room no$")
	public void user_does_not_enter_Building_name_and_room_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		conferencePageFactory.setPersonCount(2);
		conferencePageFactory.setRooms("");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please fill the Building & Room No'$")
	public void display_Please_fill_the_Building_Room_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter Area Name$")
	public void user_does_not_enter_Area_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		conferencePageFactory.setPersonCount(2);
		conferencePageFactory.setRooms("asd 2");
		conferencePageFactory.setArea("");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please fill Area Name'$")
	public void display_Please_fill_Area_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		conferencePageFactory.setPersonCount(2);
		conferencePageFactory.setRooms("asd 2");
		conferencePageFactory.setArea("asf");
		conferencePageFactory.setCity("");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please select City'$")
	public void display_Please_select_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		conferencePageFactory.setPersonCount(2);
		conferencePageFactory.setRooms("asd 2");
		conferencePageFactory.setArea("asf");
		conferencePageFactory.setCity("Select City");
		conferencePageFactory.setState("");
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please select State'$")
	public void display_Please_select_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid Conference full-Access\\(member\\) or Conference full-Access\\(non-member\\)$")
	public void user_enters_invalid_Conference_full_Access_member_or_Conference_full_Access_non_member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		conferencePageFactory.setFirstName("Yogini");
		conferencePageFactory.setLastName("Naik");
		conferencePageFactory.setEmail("yogini@gmail.com");
		conferencePageFactory.setContactNo("9922010130");
		conferencePageFactory.setPersonCount(2);
		conferencePageFactory.setRooms("asd 2");
		conferencePageFactory.setArea("asf");
		conferencePageFactory.setCity("Select City");
		conferencePageFactory.setState("Select State");
		conferencePageFactory.setFullAccess("");;
		conferencePageFactory.setNextButton();
	}

	@Then("^display 'Please select MemberShip Status'$")
	public void display_Please_select_MemberShip_Status() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please Select MemeberShip status";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();


	}


}
