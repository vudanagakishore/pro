package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client 
{
    /**
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        ProductDetails p = new ProductDetails();
        while(true)
        {
        	System.out.println("1)   Update Product Price");
        	System.out.println("2)   Exit");
        	
        	//This is for Entering input By the User
        	
        	int choice  = sc.nextInt();
        	
        	switch(choice)
        	{
        	case 1:
        		//System.out.println("1");
        		p.updateDetails();
        		break;
        	case 2:
        		System.out.println("END");
        		break;
        	default :
        		System.out.println("Enter correct choice");
        		break;
        	
        	
        	}
        }
    }
}

class ProductDetails
{
	Scanner sc = new Scanner(System.in);
	Product p;
	ProductService s;
	
	public ProductDetails()
	{
		p = new Product();
		s = new ProductService();
		
	}
	
	public void updateDetails()
	{
		
		String Category;
		 do {
	            System.out.println("Enter the Product Category :");
	            Category = sc.nextLine();
	            }
	            while(!s.isCategoryValid(Category));
		 int hike;
		 do {
	            System.out.println("Enter hike Rate :");
	            hike = sc.nextInt();
	            }
	            while(!s.ishHikeValid(hike));
		try {
			s.updateProducts(Category, hike);
		} 
		catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}


class Product
{
	String productCategory;
	int hikeRate;
	public Product(String productCategory, int hikeRate) {
		super();
		this.productCategory = productCategory;
		this.hikeRate = hikeRate;
	}
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getHikeRate() {
		return hikeRate;
	}
	public void setHikeRate(int hikeRate) {
		this.hikeRate = hikeRate;
	}

	
	
}